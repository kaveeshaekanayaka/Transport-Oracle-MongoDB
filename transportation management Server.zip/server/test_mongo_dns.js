require('dotenv').config();
const dns = require('dns');
dns.setServers(['8.8.8.8', '1.1.1.1']);
const mongoose = require('mongoose');

const customLookup = (hostname, options, callback) => {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }
  dns.resolve4(hostname, (err, addresses) => {
    if (err || !addresses || addresses.length === 0) {
      return dns.lookup(hostname, options, callback);
    }
    callback(null, addresses[0], 4);
  });
};

async function testMongo() {
  console.log('Testing Mongo with customLookup...');
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      lookup: customLookup,
      serverSelectionTimeoutMS: 10000
    });
    console.log('CONNECTED TO MONGO! Database:', mongoose.connection.name);
    const collections = await mongoose.connection.db.listCollections().toArray();
    console.log('Collections:', collections.map(c => c.name));
    await mongoose.disconnect();
  } catch (err) {
    console.error('Mongo test error:', err);
  }
}

testMongo();
