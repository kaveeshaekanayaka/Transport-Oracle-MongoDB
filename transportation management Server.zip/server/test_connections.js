require('dotenv').config();
const dns = require('dns');
try { dns.setServers(['8.8.8.8', '1.1.1.1']); } catch(e) {}

const originalLookup = dns.lookup;
dns.lookup = function(hostname, options, callback) {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }
  dns.resolve4(hostname, (err, addresses) => {
    if (!err && addresses && addresses.length > 0) {
      if (options && options.all) {
        return callback(null, addresses.map(addr => ({ address: addr, family: 4 })));
      }
      return callback(null, addresses[0], 4);
    }
    return originalLookup(hostname, options, callback);
  });
};
const oracledb = require('oracledb');
const mongoose = require('mongoose');

async function testConnections() {
  console.log('Testing Oracle connection...');
  try {
    const connection = await oracledb.getConnection({
      user: process.env.ORACLE_USER || 'system',
      password: process.env.ORACLE_PASSWORD || '2006',
      connectString: process.env.ORACLE_CONNECT_STRING || 'localhost:1521/XE'
    });
    const result = await connection.execute('SELECT sysdate FROM dual');
    console.log('Oracle Connected successfully! Result:', result.rows);
    await connection.close();
  } catch (err) {
    console.error('Oracle connection failed:', err.message);
  }

  console.log('Testing MongoDB connection...');
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 8000
    });
    console.log('MongoDB Connected successfully! DB Name:', mongoose.connection.name);
    const collections = await mongoose.connection.db.listCollections().toArray();
    console.log('MongoDB Collections:', collections.map(c => c.name));
    await mongoose.disconnect();
  } catch (err) {
    console.error('MongoDB connection failed:', err.message);
  }
}

testConnections();
