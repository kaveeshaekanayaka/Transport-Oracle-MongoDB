require('dotenv').config();
const dns = require('dns');
try {
  dns.setServers(['8.8.8.8', '1.1.1.1']);
} catch (e) {
  console.log('Custom DNS set note:', e.message);
}

// Hook Google DNS into dns.lookup so MongoDB Atlas shards always resolve reliably across any ISP
const originalLookup = dns.lookup;
dns.lookup = function(hostname, options, callback) {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }
  dns.resolve4(hostname, (err, addresses) => {
    if (!err && addresses && addresses.length > 0) {
      if (options && options.all) {
        return callback(null, addresses.map(addr => ({ address: addr, family: 4 })));
      }
      return callback(null, addresses[0], 4);
    }
    return originalLookup(hostname, options, callback);
  });
};

const express = require('express');
const cors = require('cors');
const oracledb = require('oracledb');
const mongoose = require('mongoose');

// Auto format oracledb objects
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.autoCommit = true;

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Connection status trackers
let oracleConnected = false;
let oracleError = null;
let mongoConnected = false;
let mongoError = null;

// Oracle Connection Pool Helper
const oracleConfig = {
  user: process.env.ORACLE_USER || 'system',
  password: process.env.ORACLE_PASSWORD || '2006',
  connectString: process.env.ORACLE_CONNECT_STRING || 'localhost:1521/XE'
};

async function getOracleConnection() {
  return await oracledb.getConnection(oracleConfig);
}

// Check Oracle initial connection
async function checkOracle() {
  try {
    const conn = await getOracleConnection();
    await conn.execute('SELECT 1 FROM DUAL');
    await conn.close();
    oracleConnected = true;
    oracleError = null;
    console.log('Oracle Database: Connected successfully.');
  } catch (err) {
    oracleConnected = false;
    oracleError = err.message;
    console.error('Oracle Database Connection Error:', err.message);
  }
}

// MongoDB Schemas matching the 4 collections in SmartMoveDB
const AnnouncementSchema = new mongoose.Schema({
  title: { type: String, required: true },
  message: { type: String, required: true },
  type: { type: String, default: 'General' }, // Delay, Schedule, General, Emergency
  date: { type: Date, default: Date.now }
});

const ReviewSchema = new mongoose.Schema({
  routeId: { type: String, required: true },
  passengerName: { type: String, required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comment: { type: String, required: true },
  driverId: { type: String, default: 'D101' },
  vehicleId: { type: String, default: 'V101' },
  createdAt: { type: Date, default: Date.now }
});

const VehicleDocSchema = new mongoose.Schema({
  vehicleId: { type: String, required: true },
  docType: { type: String, required: true }, // Insurance, Revenue License, Emission Test
  docNumber: { type: String, required: true },
  expiryDate: { type: String, required: true },
  fileUrl: { type: String, default: 'https://docs.smartmove.lk/doc.pdf' },
  status: { type: String, default: 'Valid' }
});

const TripMediaSchema = new mongoose.Schema({
  tripId: { type: String, required: true },
  caption: { type: String, required: true },
  mediaType: { type: String, default: 'Image' }, // Image, Video
  url: { type: String, default: 'https://images.smartmove.lk/trip.jpg' },
  uploadedAt: { type: Date, default: Date.now }
});

const Announcement = mongoose.model('Announcement', AnnouncementSchema, 'announcements');
const PassengerReview = mongoose.model('PassengerReview', ReviewSchema, 'passenger_reviews');
const VehicleDocument = mongoose.model('VehicleDocument', VehicleDocSchema, 'vehicle_documents');
const TripMedia = mongoose.model('TripMedia', TripMediaSchema, 'trip_media');

// In-memory fallback stores if MongoDB Atlas has IP-whitelist restriction
let memoryAnnouncements = [
  { _id: 'm1', title: 'Route R101 Express Service', message: 'Express bus service operational every morning 08:00 AM from Colombo to Kandy.', type: 'Schedule', date: new Date() },
  { _id: 'm2', title: 'Weather Warning for Southern Expressway', message: 'Heavy rains reported. Speeds capped at 70 km/h for safety.', type: 'Alert', date: new Date() }
];

let memoryReviews = [
  { _id: 'r1', routeId: 'R101', passengerName: 'Kasun Rajitha', rating: 5, comment: 'Comfortable seats and on-time departure! Driver Sunil was very professional.', driverId: 'D101', vehicleId: 'V101', createdAt: new Date() },
  { _id: 'r2', routeId: 'R102', passengerName: 'Ruwan Gamage', rating: 4, comment: 'Clean van and smooth ride to Galle. AC was working properly.', driverId: 'D102', vehicleId: 'V102', createdAt: new Date() },
  { _id: 'r3', routeId: 'R101', passengerName: 'Samanthi Perera', rating: 5, comment: 'Great travel experience with SmartMove. Will book again!', driverId: 'D101', vehicleId: 'V101', createdAt: new Date() }
];

let memoryDocs = [
  { _id: 'd1', vehicleId: 'V101', docType: 'Comprehensive Insurance', docNumber: 'INS-2026-9901', expiryDate: '2027-03-31', fileUrl: 'https://smartmove.lk/docs/v101_ins.pdf', status: 'Valid' },
  { _id: 'd2', vehicleId: 'V101', docType: 'Revenue License', docNumber: 'REV-WP-10493', expiryDate: '2026-12-31', fileUrl: 'https://smartmove.lk/docs/v101_rev.pdf', status: 'Valid' },
  { _id: 'd3', vehicleId: 'V102', docType: 'Fitness Certificate', docNumber: 'FIT-2026-0044', expiryDate: '2027-01-15', fileUrl: 'https://smartmove.lk/docs/v102_fit.pdf', status: 'Valid' }
];

let memoryMedia = [
  { _id: 'med1', tripId: 'T101', caption: 'Morning departure from Colombo Fort terminal', mediaType: 'Image', url: 'https://images.smartmove.lk/t101_colombo.jpg', uploadedAt: new Date() },
  { _id: 'med2', tripId: 'T102', caption: 'Scenic coastal highway view en route to Galle', mediaType: 'Image', url: 'https://images.smartmove.lk/t102_galle.jpg', uploadedAt: new Date() }
];

// Check MongoDB Connection
async function connectMongo() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 10000
    });
    mongoConnected = true;
    mongoError = null;
    console.log('MongoDB: Connected successfully to SmartMoveDB.');

    // Seed initial docs if empty
    const annCount = await Announcement.countDocuments();
    if (annCount === 0) {
      await Announcement.insertMany(memoryAnnouncements.map(({ _id, ...rest }) => rest));
    }
    const revCount = await PassengerReview.countDocuments();
    if (revCount === 0) {
      await PassengerReview.insertMany(memoryReviews.map(({ _id, ...rest }) => rest));
    }
    const docCount = await VehicleDocument.countDocuments();
    if (docCount === 0) {
      await VehicleDocument.insertMany(memoryDocs.map(({ _id, ...rest }) => rest));
    }
    const medCount = await TripMedia.countDocuments();
    if (medCount === 0) {
      await TripMedia.insertMany(memoryMedia.map(({ _id, ...rest }) => rest));
    }
  } catch (err) {
    mongoConnected = false;
    mongoError = err.message;
    console.error('MongoDB Connection Error (real):', err.message);
  }
}

// -------------------------------------------------------------
// 1. SYSTEM HEALTH / STATUS
// -------------------------------------------------------------
app.get('/api/status', async (req, res) => {
  await checkOracle();
  res.json({
    oracle: {
      connected: oracleConnected,
      user: process.env.ORACLE_USER || 'system',
      database: 'Oracle Database 21c Express Edition',
      error: oracleError
    },
    mongo: {
      connected: mongoConnected,
      database: 'SmartMoveDB (Atlas NoSQL)',
      collections: ['announcements', 'passenger_reviews', 'trip_media', 'vehicle_documents'],
      error: mongoError,
      mode: mongoConnected ? 'Live MongoDB Atlas' : 'Simulated / Hybrid Buffer'
    }
  });
});

// -------------------------------------------------------------
// 2. ORACLE CRUD: VEHICLES
// -------------------------------------------------------------
app.get('/api/oracle/vehicles', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute('SELECT * FROM Vehicle ORDER BY Vehicle_ID');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.post('/api/oracle/vehicles', async (req, res) => {
  const { Vehicle_ID, Reg_No, Type, Capacity, Status } = req.body;
  if (!Vehicle_ID || !Reg_No || !Type || !Capacity) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  let conn;
  try {
    conn = await getOracleConnection();
    await conn.execute(
      `INSERT INTO Vehicle (Vehicle_ID, Reg_No, Type, Capacity, Status)
       VALUES (:id, :reg, :type, :cap, :status)`,
      {
        id: Vehicle_ID,
        reg: Reg_No,
        type: Type,
        cap: Number(Capacity),
        status: Status || 'Active'
      }
    );
    res.json({ success: true, message: 'Vehicle created successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.put('/api/oracle/vehicles/:id', async (req, res) => {
  const { id } = req.params;
  const { Status, Capacity } = req.body;
  let conn;
  try {
    conn = await getOracleConnection();
    await conn.execute(
      `UPDATE Vehicle 
       SET Status = NVL(:status, Status), Capacity = NVL(:cap, Capacity) 
       WHERE Vehicle_ID = :id`,
      {
        status: Status || null,
        cap: Capacity ? Number(Capacity) : null,
        id
      }
    );
    res.json({ success: true, message: 'Vehicle updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.delete('/api/oracle/vehicles/:id', async (req, res) => {
  const { id } = req.params;
  let conn;
  try {
    conn = await getOracleConnection();
    await conn.execute('DELETE FROM Vehicle WHERE Vehicle_ID = :id', { id });
    res.json({ success: true, message: 'Vehicle deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// -------------------------------------------------------------
// 3. ORACLE READ & WRITE: DRIVERS, ROUTES, PASSENGERS
// -------------------------------------------------------------
app.get('/api/oracle/drivers', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute('SELECT * FROM Driver ORDER BY Driver_ID');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.post('/api/oracle/drivers', async (req, res) => {
  const { Driver_ID, Name, License_No, Phone } = req.body;
  let conn;
  try {
    conn = await getOracleConnection();
    await conn.execute(
      `INSERT INTO Driver (Driver_ID, Name, License_No, Phone)
       VALUES (:id, :name, :license, :phone)`,
      { id: Driver_ID, name: Name, license: License_No, phone: Phone }
    );
    res.json({ success: true, message: 'Driver registered successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.get('/api/oracle/routes', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute('SELECT * FROM Route ORDER BY Route_ID');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.post('/api/oracle/routes', async (req, res) => {
  const { Route_ID, Start_Location, End_Location, Distance_KM, Fare } = req.body;
  let conn;
  try {
    conn = await getOracleConnection();
    await conn.execute(
      `INSERT INTO Route (Route_ID, Start_Location, End_Location, Distance_KM, Fare)
       VALUES (:id, :startLoc, :endLoc, :dist, :fare)`,
      {
        id: Route_ID,
        startLoc: Start_Location,
        endLoc: End_Location,
        dist: Number(Distance_KM),
        fare: Number(Fare)
      }
    );
    res.json({ success: true, message: 'Route added successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.get('/api/oracle/passengers', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute('SELECT * FROM Passenger ORDER BY Passenger_ID');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.get('/api/oracle/trips', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(`
      SELECT T.Trip_ID, T.Route_ID, R.Start_Location, R.End_Location, R.Fare,
             T.Vehicle_ID, V.Reg_No, V.Type AS Vehicle_Type,
             T.Driver_ID, D.Name AS Driver_Name,
             TO_CHAR(T.Departure_Time, 'YYYY-MM-DD HH24:MI') AS Departure_Time,
             TO_CHAR(T.Arrival_Time, 'YYYY-MM-DD HH24:MI') AS Arrival_Time
      FROM Trip_Schedule T
      JOIN Route R ON T.Route_ID = R.Route_ID
      JOIN Vehicle V ON T.Vehicle_ID = V.Vehicle_ID
      JOIN Driver D ON T.Driver_ID = D.Driver_ID
      ORDER BY T.Trip_ID
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.get('/api/oracle/bookings', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(`
      SELECT B.Booking_ID, B.Seat_No, B.Status, TO_CHAR(B.Booking_Date, 'YYYY-MM-DD') AS Booking_Date,
             P.Passenger_ID, P.Name AS Passenger_Name, P.Phone AS Passenger_Phone,
             T.Trip_ID, R.Start_Location, R.End_Location, R.Fare,
             PAY.Payment_ID, PAY.Amount, PAY.Payment_Method
      FROM Ticket_Booking B
      JOIN Passenger P ON B.Passenger_ID = P.Passenger_ID
      JOIN Trip_Schedule T ON B.Trip_ID = T.Trip_ID
      JOIN Route R ON T.Route_ID = R.Route_ID
      LEFT JOIN Payment PAY ON B.Booking_ID = PAY.Booking_ID
      ORDER BY B.Booking_ID DESC
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

app.post('/api/oracle/bookings', async (req, res) => {
  const { Booking_ID, Passenger_ID, Trip_ID, Seat_No, Payment_Method, Amount } = req.body;
  let conn;
  try {
    conn = await getOracleConnection();
    await conn.execute(
      `INSERT INTO Ticket_Booking (Booking_ID, Passenger_ID, Trip_ID, Booking_Date, Seat_No, Status)
       VALUES (:bid, :pid, :tid, SYSDATE, :seat, 'Confirmed')`,
      { bid: Booking_ID, pid: Passenger_ID, tid: Trip_ID, seat: Number(Seat_No) }
    );

    const paymentId = 'PAY' + Booking_ID.replace(/\D/g, '');
    await conn.execute(
      `INSERT INTO Payment (Payment_ID, Booking_ID, Amount, Payment_Date, Payment_Method)
       VALUES (:payid, :bid, :amt, SYSDATE, :method)`,
      {
        payid: paymentId,
        bid: Booking_ID,
        amt: Number(Amount),
        method: Payment_Method || 'Card'
      }
    );

    res.json({ success: true, message: 'Ticket booked and payment processed successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// -------------------------------------------------------------
// 4. ORACLE PL/SQL BUSINESS REPORTS
// -------------------------------------------------------------
// Report 1: Popular Routes
app.get('/api/oracle/reports/popular-routes', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(`
      SELECT R.Route_ID, R.Start_Location, R.End_Location, COUNT(B.Booking_ID) AS Total_Bookings
      FROM Route R
      JOIN Trip_Schedule T ON R.Route_ID = T.Route_ID
      JOIN Ticket_Booking B ON T.Trip_ID = B.Trip_ID
      GROUP BY R.Route_ID, R.Start_Location, R.End_Location
      ORDER BY Total_Bookings DESC
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// Report 2: Total Revenue Calculation (Calls PL/SQL Function Get_Total_Revenue)
app.get('/api/oracle/reports/revenue', async (req, res) => {
  const { startDate, endDate } = req.query;
  const start = startDate ? new Date(startDate) : new Date('2020-01-01');
  const end = endDate ? new Date(endDate) : new Date('2030-12-31');

  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(
      `BEGIN
         :total := Get_Total_Revenue(:p_start, :p_end);
       END;`,
      {
        p_start: start,
        p_end: end,
        total: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      }
    );
    res.json({
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0],
      totalRevenue: result.outBinds.total || 0
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// Report 3: Passenger Travel History
app.get('/api/oracle/reports/passenger-history/:id', async (req, res) => {
  const { id } = req.params;
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(
      `SELECT P.Name, B.Booking_ID, R.Start_Location, R.End_Location, 
              TO_CHAR(T.Departure_Time, 'YYYY-MM-DD HH24:MI') AS Departure_Time, B.Status
       FROM Ticket_Booking B
       JOIN Passenger P ON B.Passenger_ID = P.Passenger_ID
       JOIN Trip_Schedule T ON B.Trip_ID = T.Trip_ID
       JOIN Route R ON T.Route_ID = R.Route_ID
       WHERE P.Passenger_ID = :id`,
      { id }
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// Report 4: Vehicles Due for Maintenance
app.get('/api/oracle/reports/maintenance-due', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(`
      SELECT V.Vehicle_ID, V.Reg_No, V.Type, M.Description, TO_CHAR(M.Maintenance_Date, 'YYYY-MM-DD') AS Maintenance_Date, M.Cost
      FROM Vehicle V
      JOIN Maintenance M ON V.Vehicle_ID = M.Vehicle_ID
      WHERE V.Status = 'Maintenance' OR M.Maintenance_Date < SYSDATE - 180
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// Report 5: Driver Trips Summary
app.get('/api/oracle/reports/driver-summary', async (req, res) => {
  let conn;
  try {
    conn = await getOracleConnection();
    const result = await conn.execute(`
      SELECT D.Driver_ID, D.Name, D.Phone, COUNT(T.Trip_ID) AS Total_Trips
      FROM Driver D
      LEFT JOIN Trip_Schedule T ON D.Driver_ID = T.Driver_ID
      GROUP BY D.Driver_ID, D.Name, D.Phone
      ORDER BY Total_Trips DESC
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// -------------------------------------------------------------
// 5. MONGODB OPERATIONS (The 4 collections requested by user)
// -------------------------------------------------------------

// Collection 1: Announcements
app.get('/api/mongo/announcements', async (req, res) => {
  if (mongoConnected) {
    try {
      const data = await Announcement.find().sort({ date: -1 });
      return res.json(data);
    } catch (err) {
      console.error(err);
    }
  }
  res.json(memoryAnnouncements);
});

app.post('/api/mongo/announcements', async (req, res) => {
  const { title, message, type } = req.body;
  if (mongoConnected) {
    try {
      const item = await Announcement.create({ title, message, type });
      return res.json({ success: true, item });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }
  const newItem = { _id: 'm_' + Date.now(), title, message, type: type || 'General', date: new Date() };
  memoryAnnouncements.unshift(newItem);
  res.json({ success: true, item: newItem });
});

// Collection 2: Passenger Reviews (Search by route, top rated, keywords)
app.get('/api/mongo/reviews', async (req, res) => {
  const { route, search } = req.query;
  if (mongoConnected) {
    try {
      let filter = {};
      if (route) filter.routeId = route;
      if (search) filter.comment = { $regex: search, $options: 'i' };
      const data = await PassengerReview.find(filter).sort({ createdAt: -1 });
      return res.json(data);
    } catch (err) {
      console.error(err);
    }
  }
  let filtered = [...memoryReviews];
  if (route) filtered = filtered.filter(r => r.routeId === route);
  if (search) filtered = filtered.filter(r => r.comment.toLowerCase().includes(search.toLowerCase()));
  res.json(filtered);
});

app.post('/api/mongo/reviews', async (req, res) => {
  const { routeId, passengerName, rating, comment, driverId, vehicleId } = req.body;
  if (mongoConnected) {
    try {
      const item = await PassengerReview.create({
        routeId, passengerName, rating: Number(rating), comment, driverId, vehicleId
      });
      return res.json({ success: true, item });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }
  const newItem = {
    _id: 'rev_' + Date.now(),
    routeId, passengerName, rating: Number(rating), comment,
    driverId: driverId || 'D101', vehicleId: vehicleId || 'V101',
    createdAt: new Date()
  };
  memoryReviews.unshift(newItem);
  res.json({ success: true, item: newItem });
});

// Collection 3: Vehicle Documents
app.get('/api/mongo/vehicle-documents', async (req, res) => {
  if (mongoConnected) {
    try {
      const data = await VehicleDocument.find().sort({ expiryDate: 1 });
      return res.json(data);
    } catch (err) {
      console.error(err);
    }
  }
  res.json(memoryDocs);
});

app.post('/api/mongo/vehicle-documents', async (req, res) => {
  const { vehicleId, docType, docNumber, expiryDate, fileUrl, status } = req.body;
  if (mongoConnected) {
    try {
      const item = await VehicleDocument.create({ vehicleId, docType, docNumber, expiryDate, fileUrl, status });
      return res.json({ success: true, item });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }
  const newItem = {
    _id: 'doc_' + Date.now(),
    vehicleId, docType, docNumber, expiryDate,
    fileUrl: fileUrl || 'https://smartmove.lk/sample.pdf',
    status: status || 'Valid'
  };
  memoryDocs.unshift(newItem);
  res.json({ success: true, item: newItem });
});

// Collection 4: Trip Media
app.get('/api/mongo/trip-media', async (req, res) => {
  if (mongoConnected) {
    try {
      const data = await TripMedia.find().sort({ uploadedAt: -1 });
      return res.json(data);
    } catch (err) {
      console.error(err);
    }
  }
  res.json(memoryMedia);
});

app.post('/api/mongo/trip-media', async (req, res) => {
  const { tripId, caption, mediaType, url } = req.body;
  if (mongoConnected) {
    try {
      const item = await TripMedia.create({ tripId, caption, mediaType, url });
      return res.json({ success: true, item });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }
  const newItem = {
    _id: 'med_' + Date.now(),
    tripId, caption, mediaType: mediaType || 'Image',
    url: url || 'https://images.smartmove.lk/trip_view.jpg',
    uploadedAt: new Date()
  };
  memoryMedia.unshift(newItem);
  res.json({ success: true, item: newItem });
});

// Start Express Server and verify DBs
app.listen(PORT, async () => {
  console.log(`SmartMove Transport Solutions Server running on port ${PORT}`);
  await checkOracle();
  await connectMongo();
});
